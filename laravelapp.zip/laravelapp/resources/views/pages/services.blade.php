		@extends("includes.inc")

		@section("content")
    	<h1>{{$title}}</h1>
    	<p>
    		@if(count($services) > 0)
    			@foreach($services as $service)
    				<li>{{$service}}</li>
    			@endforeach
    		@endif
    	</p>
    	@endsection