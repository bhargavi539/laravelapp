@extends("includes.inc")

@section("content")
	<h1>Posts</h1>
	@if(count($posts) > 0)
		@foreach($posts as $post)
			<div class="jumbotron">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6 cols-xs-12">
						<img style="max-width: 100%;" src="storage/cover_image/{{$post->cover_image}}">
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 cols-xs-12">
						
						<h2><a href="/laravelapp/public/posts/{{$post->id}}">{{$post->title}}</a></h2>
						<p>{{$post->created_at}} by {{$post->user->name}}</p>

					</div>
				</div>
			</div>
		@endforeach
		{{$posts->links()}}
	@else
	<p>No Posts Available</p>
	@endif
@endsection