@extends("includes.inc")

@section("content")
	<a href="/laravelapp/public/posts" class="btn btn-info">Go Back</a>
	<hr>
	<h1 class="display-1">{{$post->title}}</h1>
	<img style="max-width: 100%;" src="../storage/cover_image/{{$post->cover_image}}">
	<br/>
	<h3 class="display-3">{{$post->body}}</h3>
	<hr>
	<p>{{$post->created_at}} by {{$post->user->name}}</p>
	<hr>
	<a href="/laravelapp/public/posts/{{$post->id}}/edit" class="btn btn-info">Edit</a>
	{{Form::open(["action"=>['PostsController@destroy', $post->id], "method" => "POST"])}}
		{{Form::hidden("_method", "DELETE")}}
		{{Form::submit("Delete", ["class" => "btn btn-danger"])}}
	{{Form::close()}}
@endsection