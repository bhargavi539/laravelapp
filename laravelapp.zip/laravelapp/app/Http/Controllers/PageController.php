<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function index(){
    	$title = "Laravel Index Page";
    	return view("pages.index", compact("title"));
    }
    public function about(){
    	$title = "Laravel About Page";
    	return view("pages.about")->with("title", $title);
    }
    public function blog(){
    	$title = "Laravel Blog";
    	return view("pages.blog", compact("title"));
    }
    public function services(){
    	$info = array(
    		"title" => "Laravel Services Page",
    		"services" => ["Web Designing", "Web Development", "Full Stack Development"]
    	);
    	return view("pages.services")->with($info);
    }
}
