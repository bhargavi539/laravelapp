<?php $__env->startSection("content"); ?>
	<h1>Posts</h1>
	<?php if(count($posts) > 0): ?>
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="jumbotron">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6 cols-xs-12">
						<img style="max-width: 100%;" src="storage/cover_image/<?php echo e($post->cover_image); ?>">
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 cols-xs-12">
						
						<h2><a href="/laravelapp/public/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h2>
						<p><?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></p>

					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($posts->links()); ?>

	<?php else: ?>
	<p>No Posts Available</p>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("includes.inc", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>