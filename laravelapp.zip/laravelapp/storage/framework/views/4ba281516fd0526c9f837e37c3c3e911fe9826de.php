<?php $__env->startSection("content"); ?>
	<a href="/laravelapp/public/posts" class="btn btn-info">Go Back</a>
	<hr>
	<h1 class="display-1"><?php echo e($post->title); ?></h1>
	<img style="max-width: 100%;" src="../storage/cover_image/<?php echo e($post->cover_image); ?>">
	<br/>
	<h3 class="display-3"><?php echo e($post->body); ?></h3>
	<hr>
	<p><?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></p>
	<hr>
	<a href="/laravelapp/public/posts/<?php echo e($post->id); ?>/edit" class="btn btn-info">Edit</a>
	<?php echo e(Form::open(["action"=>['PostsController@destroy', $post->id], "method" => "POST"])); ?>

		<?php echo e(Form::hidden("_method", "DELETE")); ?>

		<?php echo e(Form::submit("Delete", ["class" => "btn btn-danger"])); ?>

	<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("includes.inc", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>